# Homepage cards

Saved November 8, 2026, before removal from the active homepage.

This archive preserves Weight Loss, Metabolic Health, Longevity, Bloodwork,
and Peptide Therapy. It includes the original photographs, full card text,
icons, flat overlapping layout, four-second continuous rotation, touch and
keyboard controls, and the centered reading dialog with its close button.

## Preview

Extract the whole archive and open index.html. The preview uses only the
files in this archive; it does not depend on the current website's files.

## Restore later

1. Use component.html for the original services section and reading dialog.
   It includes the Explore the Care / that fits / Your Goals heading.
2. Restore the five images under assets/home/ if needed.
3. Compare css/home.css with the active stylesheet and restore only the
   service-card, stacked-deck, responsive, and reading-dialog rules. The
   stylesheet snapshots also contain unrelated page styling; do not replace
   current stylesheets wholesale.
4. js/homepage-cards.js contains the isolated deck behavior. Load it once,
   or retain the existing matching deck code in js/home-services.js.
5. Keep the product carousel under its current heading or give it a separate
   heading when restoring the original deck. Avoid duplicate section IDs.

source/index.html and source/js/home-services.js preserve the complete
pre-removal source for reference. Do not overwrite later site changes with
these snapshots. manifest.json records SHA-256 hashes of every saved file.
